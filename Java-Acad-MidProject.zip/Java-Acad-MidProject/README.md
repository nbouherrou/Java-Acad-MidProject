Java-Acad-MidProject
====================

Mid-project for Java Academy Class test
